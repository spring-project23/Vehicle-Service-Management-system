import Table from 'react-bootstrap/Table';
import React from 'react';


function Tables() {
  return (
    <Table className="table" striped bordered hover>
      <thead>
        <tr>
          <th className='tableth '>hfghjghnn</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td className='tabletd '>1fhjnvn</td>
        </tr>
      </tbody>
    </Table>
  );
}

export default Tables;